import { useRef, useState } from 'react'
import heroImage from './imports/vantix-hero.png'

// ─── Tokens ──────────────────────────────────────────────────────────────────

const T = {
  base: '#F8F7F3',
  canvas: '#D5D8DE',
  surface: '#E8EEF7',
  navy: '#1B2A4A',
  navyDark: '#121E36',
  text: '#1A1D23',
  muted: '#5B6472',
  border: '#CBD3DF',
  borderLight: '#E2E7EF',
  accent: '#3D6FE0',
  accentLight: '#87A8F2',
  onNavy: '#F7F9FC',
  onNavyMuted: '#B9C5D8',
  bronze: '#A0663A',
  silver: '#7A8899',
  gold: '#9A7230',
  serif: "'DM Serif Display', Georgia, serif",
  sans: "'Manrope', system-ui, sans-serif",
  mono: "'IBM Plex Mono', monospace",
} as const

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen = 'catalog' | 'recommended' | 'orders' | 'account'
type Payment = 'pix' | 'card' | 'boleto'
type Loyalty = 'bronze' | 'prata' | 'ouro'
type CustomerState = 'new' | 'returning' | 'leveling'
type ViewMode = 'desktop' | 'mobile'

interface Product {
  id: number
  name: string
  brand: string
  desc: string
  image: string
  imageAlt: string
  price: number
  category: string
  stock: number
  popular?: boolean
  recommendReason?: string
}

interface CartItem {
  product: Product
  qty: number
}

interface Order {
  id: string
  date: string
  payment: Payment
  status: 'entregue' | 'em trânsito' | 'processando'
  items: { name: string; qty: number; price: number }[]
  total: number
  points: number
}

// ─── Data ─────────────────────────────────────────────────────────────────────

const PRODUCTS: Product[] = [
  {
    id: 1,
    name: 'ThinkPad X1 Carbon Gen 12',
    brand: 'Lenovo',
    desc: 'Core Ultra 7 165H · 32 GB LPDDR5 · 1 TB NVMe · 14" IPS 2,8K · 1,12 kg',
    image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Notebook premium aberto sobre uma mesa',
    price: 10490,
    category: 'Notebooks',
    stock: 5,
    popular: true,
    recommendReason: 'Você comprou acessórios para notebook nos últimos 60 dias.',
  },
  {
    id: 2,
    name: 'XPS 15 9530',
    brand: 'Dell',
    desc: 'Core i7-13700H · 32 GB DDR5 · 1 TB NVMe · OLED 3,5K touch · RTX 4060',
    image: 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Notebook fino aberto em uma estação de trabalho',
    price: 13290,
    category: 'Notebooks',
    stock: 3,
    popular: true,
  },
  {
    id: 3,
    name: 'Zephyrus G14 2024',
    brand: 'Asus ROG',
    desc: 'Ryzen 9 8945HS · 32 GB DDR5 · 1 TB NVMe · OLED 2,8K 120Hz · RTX 4070',
    image: 'https://images.unsplash.com/photo-1511385348-a52b4a160dc2?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Notebook de alto desempenho em acabamento escuro',
    price: 11950,
    category: 'Notebooks',
    stock: 4,
  },
  {
    id: 4,
    name: 'UltraSharp U2724D',
    brand: 'Dell',
    desc: '27" IPS Black 4K · USB-C 140W · KVM · 2000:1 · calor de cor D50',
    image: 'https://images.unsplash.com/photo-1547658718-1cdaa0852790?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Monitor profissional em uma mesa minimalista',
    price: 4190,
    category: 'Monitores',
    stock: 8,
    popular: true,
    recommendReason: 'Compatível com o notebook que você comprou em novembro.',
  },
  {
    id: 5,
    name: 'Odyssey OLED G8 32"',
    brand: 'Samsung',
    desc: 'OLED QHD 240Hz · 0,03ms · DisplayPort 1.4 · USB hub · HDR True Black 400',
    image: 'https://images.unsplash.com/photo-1587831990711-23ca6441447b?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Monitor widescreen em uma estação de jogos',
    price: 5890,
    category: 'Monitores',
    stock: 6,
  },
  {
    id: 6,
    name: 'ProArt PA329CRV',
    brand: 'Asus',
    desc: '32" IPS 4K · 98% DCI-P3 · USB-C 96W · calibração de fábrica Delta-E < 2',
    image: 'https://images.unsplash.com/photo-1510519138101-570d1dca3d66?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Monitor para criação em uma estação de trabalho',
    price: 4750,
    category: 'Monitores',
    stock: 7,
  },
  {
    id: 7,
    name: 'MX Master 3S',
    brand: 'Logitech',
    desc: 'Mouse sem fio · 8000 DPI sensor Darkfield · silencioso · USB-C · Bolt',
    image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Mouse sem fio ergonômico em detalhe',
    price: 649,
    category: 'Periféricos',
    stock: 22,
    popular: true,
    recommendReason: 'Comprado junto com ThinkPad por 74% dos clientes com perfil similar.',
  },
  {
    id: 8,
    name: 'K8 Pro',
    brand: 'Keychron',
    desc: 'TKL mecânico · Bluetooth 5.1 + USB-C · hot-swap Gateron · retroiluminação RGB',
    image: 'https://images.unsplash.com/photo-1632079003110-d694908500da?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Teclado mecânico compacto sobre uma mesa',
    price: 720,
    category: 'Periféricos',
    stock: 15,
    popular: true,
  },
  {
    id: 9,
    name: 'Stream Deck MK.2',
    brand: 'Elgato',
    desc: '15 teclas LCD programáveis · USB-C · compatível com 400+ apps · suporte inclinado',
    image: 'https://images.unsplash.com/photo-1671063137261-f56fcc16dd2c?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Controlador compacto programável em uma mesa',
    price: 890,
    category: 'Periféricos',
    stock: 11,
  },
  {
    id: 10,
    name: 'WH-1000XM5',
    brand: 'Sony',
    desc: 'Over-ear ANC multicamadas · 30h de bateria · LDAC · microfone duplo para chamadas',
    image: 'https://images.unsplash.com/photo-1505740106531-4243f3831c78?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Headphone sem fio preto em destaque',
    price: 1990,
    category: 'Áudio',
    stock: 14,
    popular: true,
    recommendReason: 'Você tem notebooks de uso intensivo — cancelamento de ruído é recomendado.',
  },
  {
    id: 11,
    name: 'QuietComfort Ultra',
    brand: 'Bose',
    desc: 'Over-ear ANC com áudio espacial · CustomTune · 24h de bateria · multipoint',
    image: 'https://images.unsplash.com/photo-1615788237268-5bd2148d2b10?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Headphone over-ear premium sobre uma mesa',
    price: 2290,
    category: 'Áudio',
    stock: 9,
  },
  {
    id: 12,
    name: 'Wave:3',
    brand: 'Elgato',
    desc: 'Microfone USB cardioide · 24 bits/96 kHz · controle de ganho físico · clipguard',
    image: 'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=900',
    imageAlt: 'Microfone condensador de estúdio em detalhe',
    price: 1150,
    category: 'Áudio',
    stock: 13,
  },
]

const ORDERS: Order[] = [
  {
    id: 'VTX-2024-1847',
    date: '14 nov. 2024',
    payment: 'card',
    status: 'em trânsito',
    items: [
      { name: 'ThinkPad X1 Carbon Gen 12', qty: 1, price: 10490 },
      { name: 'MX Master 3S', qty: 1, price: 649 },
    ],
    total: 11139,
    points: 1113,
  },
  {
    id: 'VTX-2024-1201',
    date: '3 set. 2024',
    payment: 'pix',
    status: 'entregue',
    items: [{ name: 'WH-1000XM5', qty: 1, price: 1990 }],
    total: 1990,
    points: 199,
  },
  {
    id: 'VTX-2024-0883',
    date: '18 jul. 2024',
    payment: 'boleto',
    status: 'entregue',
    items: [
      { name: 'K8 Pro', qty: 1, price: 720 },
      { name: 'Stream Deck MK.2', qty: 1, price: 890 },
    ],
    total: 1610,
    points: 161,
  },
  {
    id: 'VTX-2024-0441',
    date: '22 abr. 2024',
    payment: 'card',
    status: 'entregue',
    items: [{ name: 'UltraSharp U2724D', qty: 1, price: 4190 }],
    total: 4190,
    points: 419,
  },
]

// ─── Helpers ──────────────────────────────────────────────────────────────────

const fmtBRL = (n: number) =>
  n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })

const loyaltyData: Record<Loyalty, { color: string; label: string; min: number }> = {
  bronze: { color: T.bronze, label: 'Bronze', min: 0 },
  prata: { color: T.silver, label: 'Prata', min: 1000 },
  ouro: { color: T.gold, label: 'Ouro', min: 3000 },
}

const paymentFee: Record<Payment, number> = { pix: 0, card: 0.03, boleto: 0.01 }

const CATEGORIES = ['Todos', 'Notebooks', 'Monitores', 'Periféricos', 'Áudio']

// ─── Primitive styles ─────────────────────────────────────────────────────────

const s = {
  h1: {
    fontFamily: T.serif,
    fontWeight: 500,
    fontSize: 24,
    color: T.navy,
    letterSpacing: '-0.02em',
    lineHeight: 1.15,
  } as React.CSSProperties,

  h2: {
    fontFamily: T.serif,
    fontWeight: 500,
    fontSize: 18,
    color: T.navy,
    letterSpacing: '-0.01em',
    lineHeight: 1.25,
  } as React.CSSProperties,

  h3: {
    fontFamily: T.sans,
    fontWeight: 500,
    fontSize: 14,
    color: T.text,
    lineHeight: 1.3,
  } as React.CSSProperties,

  label: {
    fontFamily: T.sans,
    fontWeight: 500,
    fontSize: 10,
    color: T.muted,
    lineHeight: 1.4,
    textTransform: 'uppercase' as const,
    letterSpacing: '0.07em',
  } as React.CSSProperties,

  body: {
    fontFamily: T.sans,
    fontWeight: 400,
    fontSize: 13,
    color: T.text,
    lineHeight: 1.55,
  } as React.CSSProperties,

  bodySmall: {
    fontFamily: T.sans,
    fontWeight: 400,
    fontSize: 12,
    color: T.muted,
    lineHeight: 1.55,
  } as React.CSSProperties,

  price: {
    fontFamily: T.mono,
    fontWeight: 600,
    fontSize: 15,
    color: T.text,
    fontVariantNumeric: 'tabular-nums',
    letterSpacing: '-0.02em',
  } as React.CSSProperties,

  priceLg: {
    fontFamily: T.mono,
    fontWeight: 600,
    fontSize: 20,
    color: T.navy,
    fontVariantNumeric: 'tabular-nums',
    letterSpacing: '-0.03em',
  } as React.CSSProperties,

  divider: {
    height: 1,
    background: T.border,
    border: 'none',
    margin: 0,
  } as React.CSSProperties,

  btnPrimary: {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: T.navy,
    color: T.onNavy,
    fontFamily: T.sans,
    fontWeight: 500,
    fontSize: 11,
    letterSpacing: '0.035em',
    textTransform: 'uppercase' as const,
    border: 'none',
    borderRadius: 6,
    cursor: 'pointer',
    padding: '9px 18px',
    transition: 'background 0.15s',
  } as React.CSSProperties,

  btnGhost: {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'transparent',
    color: T.muted,
    fontFamily: T.sans,
    fontWeight: 500,
    fontSize: 11,
    letterSpacing: '0.035em',
    textTransform: 'uppercase' as const,
    border: `1px solid ${T.border}`,
    borderRadius: 6,
    cursor: 'pointer',
    padding: '8px 16px',
    transition: 'border-color 0.15s, color 0.15s',
  } as React.CSSProperties,
}

// ─── Status badge ──────────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const cfg: Record<string, { bg: string; color: string; label: string }> = {
    entregue: { bg: 'rgba(122,136,153,0.12)', color: T.silver, label: 'Entregue' },
    'em trânsito': { bg: 'rgba(61,111,224,0.10)', color: T.accent, label: 'Em trânsito' },
    processando: { bg: 'rgba(160,102,58,0.12)', color: T.bronze, label: 'Processando' },
  }
  const c = cfg[status] ?? cfg['entregue']
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        padding: '3px 8px',
        borderRadius: 2,
        background: c.bg,
        color: c.color,
        fontFamily: T.sans,
        fontWeight: 500,
        fontSize: 10,
        letterSpacing: '0.06em',
        textTransform: 'uppercase',
        whiteSpace: 'nowrap',
      }}
    >
      {c.label}
    </span>
  )
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────

function Sidebar({
  screen,
  onNav,
  onNewCustomer,
  points,
  loyalty,
  levelingUp,
  customerState,
}: {
  screen: Screen
  onNav: (s: Screen) => void
  onNewCustomer: () => void
  points: number
  loyalty: Loyalty
  levelingUp: boolean
  customerState: CustomerState
}) {
  const ldata = loyaltyData[loyalty]
  const nextLoyalty: Loyalty | null =
    loyalty === 'bronze' ? 'prata' : loyalty === 'prata' ? 'ouro' : null
  const nextMin = nextLoyalty ? loyaltyData[nextLoyalty].min : null
  const progress = nextMin ? Math.min(points / nextMin, 1) : 1

  const navItems: { id: Screen; label: string }[] = [
    { id: 'catalog', label: 'Catálogo' },
    { id: 'recommended', label: 'Recomendados' },
    { id: 'orders', label: 'Meus pedidos' },
    { id: 'account', label: 'Painel do cliente' },
  ]

  return (
    <aside
      style={{
        width: 224,
        minWidth: 224,
        height: '100vh',
        background: `linear-gradient(180deg, ${T.navy} 0%, ${T.navyDark} 100%)`,
        borderRight: `1px solid ${T.navyDark}`,
        display: 'flex',
        flexDirection: 'column',
        flexShrink: 0,
        overflow: 'hidden',
      }}
    >
      {/* Logo */}
      <div style={{ padding: '28px 24px 22px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
          <span
            style={{
              fontFamily: T.serif,
              fontWeight: 500,
              fontSize: 19,
              color: T.onNavy,
              letterSpacing: '-0.025em',
            }}
          >
            Vantix
          </span>
          <span
            style={{
              width: 5,
              height: 5,
              borderRadius: '50%',
              background: T.accent,
              display: 'inline-block',
              flexShrink: 0,
            }}
          />
        </div>
        <div
          style={{
            marginTop: 4,
            fontFamily: T.sans,
            fontSize: 10,
            fontWeight: 500,
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            color: 'rgba(185, 197, 216, 0.55)',
          }}
        >
          Eletrônicos &amp; Informática
        </div>
      </div>

      <div
        style={{ height: 1, background: 'rgba(255,255,255,0.07)', margin: '0 20px' }}
      />

      {/* Nav */}
      <nav style={{ padding: '16px 12px 0', flex: 1 }}>
        {navItems.map((item) => {
          const active = screen === item.id
          return (
            <button
              key={item.id}
              onClick={() => onNav(item.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                width: '100%',
                padding: '9px 12px',
                textAlign: 'left',
                background: active ? 'rgba(255,255,255,0.08)' : 'transparent',
                borderLeft: active ? `2px solid ${T.accent}` : '2px solid transparent',
                border: 'none',
                borderRadius: '0 3px 3px 0',
                color: active ? T.onNavy : T.onNavyMuted,
                fontFamily: T.sans,
                fontWeight: active ? 500 : 400,
                fontSize: 13,
                cursor: 'pointer',
                marginBottom: 2,
                transition: 'color 0.12s, background 0.12s',
                outline: 'none',
              }}
            >
              {item.label}
            </button>
          )
        })}

        <div
          style={{
            height: 1,
            background: 'rgba(255,255,255,0.07)',
            margin: '14px 12px',
          }}
        />

        {customerState === 'new' ? (
          <button
            onClick={onNewCustomer}
            style={{
              display: 'block',
              width: '100%',
              padding: '9px 12px',
              textAlign: 'left',
              background: 'transparent',
              border: 'none',
              color: T.accentLight,
              fontFamily: T.sans,
              fontWeight: 500,
              fontSize: 12,
              cursor: 'pointer',
              outline: 'none',
              letterSpacing: '0.02em',
            }}
          >
            Criar conta →
          </button>
        ) : (
          <button
            onClick={onNewCustomer}
            style={{
              display: 'block',
              width: '100%',
              padding: '9px 12px',
              textAlign: 'left',
              background: 'transparent',
              border: 'none',
              color: T.onNavyMuted,
              fontFamily: T.sans,
              fontWeight: 400,
              fontSize: 12,
              cursor: 'pointer',
              outline: 'none',
            }}
          >
            Novo cliente
          </button>
        )}
      </nav>

      {/* Customer card */}
      <div
        style={{
          margin: '0 12px 20px',
          border: '1px solid rgba(255,255,255,0.1)',
          borderRadius: 4,
          overflow: 'hidden',
          background: 'rgba(0,0,0,0.18)',
        }}
      >
        {/* Loyalty strip */}
        <div
          style={{
            height: 2,
            background: levelingUp ? loyaltyData[nextLoyalty ?? loyalty].color : ldata.color,
            transition: 'background 1.2s ease',
          }}
        />

        <div style={{ padding: '14px 16px 16px' }}>
          {customerState === 'new' ? (
            <div>
              <div style={{ ...s.label, color: 'rgba(185,197,216,0.6)', marginBottom: 6 }}>
                Visitante
              </div>
              <div style={{ ...s.bodySmall, color: T.onNavyMuted, lineHeight: 1.6 }}>
                Crie uma conta para acumular pontos e ver recomendações personalizadas.
              </div>
            </div>
          ) : (
            <>
              <div style={{ ...s.label, color: 'rgba(185,197,216,0.55)', marginBottom: 3 }}>
                Cliente
              </div>
              <div
                style={{
                  fontFamily: T.sans,
                  fontWeight: 500,
                  fontSize: 13,
                  color: T.onNavy,
                  marginBottom: 2,
                }}
              >
                Rafael Monteiro
              </div>
              <div
                style={{
                  fontFamily: T.sans,
                  fontWeight: 500,
                  fontSize: 11,
                  color: levelingUp ? loyaltyData[nextLoyalty ?? loyalty].color : ldata.color,
                  transition: 'color 1.2s ease',
                  marginBottom: 14,
                  letterSpacing: '0.04em',
                  textTransform: 'uppercase',
                }}
              >
                {levelingUp && nextLoyalty ? loyaltyData[nextLoyalty].label : ldata.label}
              </div>

              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'baseline',
                  marginBottom: 10,
                }}
              >
                <span style={{ ...s.label, color: 'rgba(185,197,216,0.55)' }}>Pontos</span>
                <span
                  style={{
                    fontFamily: T.mono,
                    fontWeight: 600,
                    fontSize: 16,
                    color: T.accentLight,
                    fontVariantNumeric: 'tabular-nums',
                    letterSpacing: '-0.02em',
                  }}
                >
                  {points.toLocaleString('pt-BR')}
                </span>
              </div>

              {nextMin && (
                <div>
                  <div
                    style={{
                      height: 2,
                      background: 'rgba(255,255,255,0.1)',
                      borderRadius: 1,
                      overflow: 'hidden',
                    }}
                  >
                    <div
                      style={{
                        height: '100%',
                        width: `${progress * 100}%`,
                        background: ldata.color,
                        transition: 'width 0.8s ease, background 1.2s ease',
                        borderRadius: 1,
                      }}
                    />
                  </div>
                  <div style={{ ...s.label, color: 'rgba(185,197,216,0.45)', marginTop: 5 }}>
                    {(nextMin - points).toLocaleString('pt-BR')} pts para{' '}
                    {nextLoyalty && loyaltyData[nextLoyalty].label}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </aside>
  )
}

// ─── Store header ─────────────────────────────────────────────────────────────

function StoreHeader({
  screen,
  onNav,
  onNewCustomer,
  searchQuery,
  onSearch,
  points,
  loyalty,
  customerState,
}: {
  screen: Screen
  onNav: (s: Screen) => void
  onNewCustomer: () => void
  searchQuery: string
  onSearch: (query: string) => void
  points: number
  loyalty: Loyalty
  customerState: CustomerState
}) {
  const navItems: { id: Screen; label: string }[] = [
    { id: 'catalog', label: 'Início' },
    { id: 'recommended', label: 'Para você' },
    { id: 'orders', label: 'Pedidos' },
    { id: 'account', label: 'Minha conta' },
  ]

  return (
    <header
      style={{
        height: 68,
        padding: '0 34px',
        background: T.navyDark,
        color: T.onNavy,
        display: 'flex',
        alignItems: 'center',
        gap: 36,
        borderBottom: `1px solid rgba(255,255,255,0.1)`,
        flexShrink: 0,
        zIndex: 5,
      }}
    >
      <button
        onClick={() => onNav('catalog')}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          border: 'none',
          background: 'transparent',
          color: T.onNavy,
          cursor: 'pointer',
          padding: 0,
        }}
      >
        <span
          style={{
            width: 28,
            height: 28,
            display: 'grid',
            placeItems: 'center',
            borderRadius: 7,
            background: T.accent,
            fontFamily: T.serif,
            fontSize: 16,
          }}
        >
          V
        </span>
        <span
          style={{
            fontFamily: T.sans,
            fontWeight: 700,
            fontSize: 17,
            letterSpacing: '0.16em',
          }}
        >
          VANTIX
        </span>
      </button>

      <nav style={{ display: 'flex', alignItems: 'stretch', alignSelf: 'stretch', gap: 4 }}>
        {navItems.map((item) => {
          const active = screen === item.id
          return (
            <button
              key={item.id}
              onClick={() => onNav(item.id)}
              style={{
                padding: '0 14px',
                border: 'none',
                borderBottom: active ? `2px solid ${T.accentLight}` : '2px solid transparent',
                background: 'transparent',
                color: active ? T.onNavy : T.onNavyMuted,
                fontFamily: T.sans,
                fontSize: 12,
                fontWeight: active ? 600 : 500,
                cursor: 'pointer',
              }}
            >
              {item.label}
            </button>
          )
        })}
      </nav>

      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 12 }}>
        <label
          style={{
            width: 230,
            height: 36,
            border: `1px solid rgba(255,255,255,0.16)`,
            borderRadius: 18,
            padding: '0 14px',
            color: T.onNavyMuted,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            fontFamily: T.sans,
            fontSize: 11,
          }}
        >
          <input
            type="search"
            value={searchQuery}
            onChange={(event) => {
              onSearch(event.target.value)
              onNav('catalog')
            }}
            placeholder="O que você procura?"
            aria-label="Pesquisar produtos"
            style={{
              width: '100%',
              border: 'none',
              outline: 'none',
              background: 'transparent',
              color: T.onNavy,
              fontFamily: T.sans,
              fontSize: 11,
            }}
          />
          <span style={{ fontFamily: T.mono, color: T.accentLight }}>⌕</span>
        </label>
        <button
          onClick={onNewCustomer}
          style={{
            border: `1px solid rgba(255,255,255,0.16)`,
            background: 'rgba(255,255,255,0.05)',
            color: T.onNavy,
            borderRadius: 18,
            padding: '8px 13px',
            cursor: 'pointer',
            fontFamily: T.sans,
            fontSize: 11,
            fontWeight: 600,
          }}
        >
          {customerState === 'new'
            ? 'Criar conta'
            : `${loyaltyData[loyalty].label} · ${points.toLocaleString('pt-BR')} pts`}
        </button>
      </div>
    </header>
  )
}

// ─── Product card ──────────────────────────────────────────────────────────────

function ProductCard({
  product,
  onAdd,
  showReason,
}: {
  product: Product
  onAdd: (p: Product) => void
  showReason?: boolean
}) {
  const [hovered, setHovered] = useState(false)

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        border: `1px solid ${hovered ? T.border : T.borderLight}`,
        borderRadius: 12,
        background: T.base,
        display: 'flex',
        flexDirection: 'column',
        gap: 0,
        overflow: 'hidden',
        boxShadow: hovered
          ? '0 18px 42px rgba(18,30,54,0.13)'
          : '0 5px 18px rgba(18,30,54,0.06)',
        transform: hovered ? 'translateY(-3px)' : 'translateY(0)',
        transition: 'border-color 0.2s, box-shadow 0.2s, transform 0.2s',
        position: 'relative',
      }}
    >
      <div
        style={{
          height: 154,
          overflow: 'hidden',
          position: 'relative',
          background: T.surface,
          borderBottom: `1px solid ${T.borderLight}`,
        }}
      >
        <img
          src={product.image}
          alt={product.imageAlt}
          loading="lazy"
          style={{
            width: '100%',
            height: '100%',
            display: 'block',
            objectFit: 'cover',
            transform: hovered ? 'scale(1.035)' : 'scale(1)',
            transition: 'transform 0.45s ease',
          }}
        />
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(180deg, transparent 58%, rgba(18,30,54,0.18) 100%)',
            pointerEvents: 'none',
          }}
        />
      </div>

      <div style={{ padding: '15px 16px 17px', display: 'flex', flexDirection: 'column', flex: 1 }}>
      {/* Top row: brand label + stock */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 10,
        }}
      >
        <span style={s.label}>{product.brand}</span>
        <span
          style={{
            ...s.label,
            color: product.stock <= 4 ? T.bronze : T.muted,
            background: product.stock <= 4 ? 'rgba(160,102,58,0.08)' : T.surface,
            padding: '3px 7px',
            borderRadius: 10,
            letterSpacing: '0.04em',
          }}
        >
          {product.stock} em estoque
        </span>
      </div>

      {/* Name */}
      <div
        style={{
          fontFamily: T.serif,
          fontWeight: 500,
          fontSize: 16,
          color: T.navy,
          lineHeight: 1.25,
          marginBottom: showReason && product.recommendReason ? 8 : 10,
          letterSpacing: '-0.01em',
        }}
      >
        {product.name}
      </div>

      {/* Reason tag */}
      {showReason && product.recommendReason && (
        <div
          style={{
            fontFamily: T.sans,
            fontSize: 11,
            color: T.accent,
            marginBottom: 8,
            lineHeight: 1.45,
            padding: '5px 8px',
            background: 'rgba(61,111,224,0.06)',
            borderRadius: 2,
            borderLeft: `2px solid ${T.accent}`,
          }}
        >
          {product.recommendReason}
        </div>
      )}

      {/* Spec string */}
      <div
        style={{
          fontFamily: T.sans,
          fontSize: 12,
          color: T.muted,
          lineHeight: 1.6,
          marginBottom: 20,
          flex: 1,
        }}
      >
        {product.desc}
      </div>

      {/* Footer: price + button */}
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'stretch',
          gap: 12,
          paddingTop: 16,
          borderTop: `1px solid ${T.borderLight}`,
          marginTop: 'auto',
        }}
      >
        <div>
          <div style={{ ...s.label, marginBottom: 3 }}>À vista</div>
          <span style={{ ...s.price, fontSize: 17 }}>{fmtBRL(product.price)}</span>
        </div>
        <button
          onClick={() => onAdd(product)}
          style={{
            ...s.btnPrimary,
            background: hovered ? T.navyDark : T.navy,
            fontSize: 10,
            width: '100%',
            minHeight: 36,
            padding: '9px 15px',
          }}
        >
          Adicionar
        </button>
      </div>
      </div>
    </div>
  )
}

// ─── Screen header ─────────────────────────────────────────────────────────────

function ScreenHeader({
  title,
  subtitle,
  right,
}: {
  title: string
  subtitle?: string
  right?: React.ReactNode
}) {
  return (
    <div
      style={{
        padding: '30px 36px 24px',
        borderBottom: `1px solid ${T.border}`,
        background: T.canvas,
        flexShrink: 0,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-end',
        gap: 16,
      }}
    >
      <div>
        <h1 style={s.h1}>{title}</h1>
        {subtitle && (
          <p style={{ ...s.bodySmall, marginTop: 5, maxWidth: 440 }}>{subtitle}</p>
        )}
      </div>
      {right && <div style={{ flexShrink: 0 }}>{right}</div>}
    </div>
  )
}

// ─── Empty state ──────────────────────────────────────────────────────────────

function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div
      style={{
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 48,
      }}
    >
      <div style={{ maxWidth: 340 }}>
        <div
          style={{
            width: 28,
            height: 2,
            background: T.accent,
            borderRadius: 1,
            marginBottom: 20,
          }}
        />
        <h2 style={{ ...s.h2, marginBottom: 10 }}>{title}</h2>
        <p style={{ ...s.body, color: T.muted, lineHeight: 1.7 }}>{body}</p>
      </div>
    </div>
  )
}

// ─── Catalog screen ────────────────────────────────────────────────────────────

function CatalogScreen({
  onAdd,
  onNavigate,
  searchQuery,
  customerState,
}: {
  onAdd: (p: Product) => void
  onNavigate: (screen: Screen) => void
  searchQuery: string
  customerState: CustomerState
}) {
  const [activeCategory, setActiveCategory] = useState('Todos')
  const productsSectionRef = useRef<HTMLDivElement>(null)

  const normalizedQuery = searchQuery.trim().toLocaleLowerCase('pt-BR')
  const searched = normalizedQuery
    ? PRODUCTS.filter((product) =>
        [product.name, product.brand, product.category, product.desc]
          .join(' ')
          .toLocaleLowerCase('pt-BR')
          .includes(normalizedQuery)
      )
    : PRODUCTS

  const filtered =
    activeCategory === 'Todos'
      ? searched
      : searched.filter((p) => p.category === activeCategory)

  const displayed =
    customerState === 'new' && !normalizedQuery
      ? filtered.filter((p) => p.popular)
      : filtered

  const categoryCards = CATEGORIES.slice(1).map((category) => ({
    category,
    image: PRODUCTS.find((product) => product.category === category)?.image ?? PRODUCTS[0].image,
  }))

  return (
    <div
      style={{
        flex: 1,
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      <div style={{ flex: 1, overflowY: 'auto', background: T.canvas }}>
        <section
          style={{
            minHeight: 300,
            padding: '48px 52px',
            background: `linear-gradient(90deg, rgba(18,30,54,0.96) 0%, rgba(27,42,74,0.8) 52%, rgba(27,42,74,0.32) 100%), url(${heroImage}) center / cover`,
            color: T.onNavy,
            display: 'flex',
            alignItems: 'center',
            position: 'relative',
            overflow: 'hidden',
          }}
        >
          <div style={{ position: 'relative', zIndex: 1, maxWidth: 530 }}>
            <div style={{ ...s.label, color: T.accentLight, marginBottom: 12 }}>
              Tecnologia · desempenho · confiança
            </div>
            <div
              style={{
                fontFamily: T.serif,
                fontSize: 38,
                lineHeight: 1.06,
                letterSpacing: '-0.025em',
                marginBottom: 14,
              }}
            >
              Tudo o que você precisa,
              <br />
              <span style={{ color: T.accentLight }}>em um só lugar.</span>
            </div>
            <p style={{ ...s.body, color: T.onNavyMuted, maxWidth: 430, marginBottom: 24 }}>
              Eletrônicos selecionados para trabalhar, criar e aproveitar cada momento com mais desempenho.
            </p>
            <button
              onClick={() => {
                setActiveCategory('Todos')
                productsSectionRef.current?.scrollIntoView({
                  behavior: 'smooth',
                  block: 'start',
                })
              }}
              style={{ ...s.btnPrimary, background: T.accent, padding: '11px 20px' }}
            >
              Ver produtos →
            </button>
          </div>
        </section>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, 1fr)',
            background: T.navyDark,
            borderTop: `1px solid rgba(255,255,255,0.1)`,
          }}
        >
          {[
            ['Entrega rápida', 'Para todo o Brasil'],
            ['Compra segura', 'Seus dados protegidos'],
            ['Pagamento flexível', 'Pix, boleto ou cartão'],
            ['Atendimento', 'Suporte especializado'],
          ].map(([title, subtitle], index) => (
            <div
              key={title}
              style={{
                padding: '17px 22px',
                borderRight: index < 3 ? `1px solid rgba(255,255,255,0.1)` : 'none',
              }}
            >
              <div style={{ fontFamily: T.sans, fontSize: 11, fontWeight: 600, color: T.onNavy }}>{title}</div>
              <div style={{ fontFamily: T.sans, fontSize: 9, color: T.onNavyMuted, marginTop: 3 }}>{subtitle}</div>
            </div>
          ))}
        </div>

        <div style={{ padding: '30px 36px 42px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 16 }}>
            <h2 style={{ ...s.h2, fontSize: 21 }}>Categorias em destaque</h2>
            <span style={s.label}>Encontre por categoria</span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 34 }}>
            {categoryCards.map(({ category, image }) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                style={{
                  height: 124,
                  border: `1px solid ${activeCategory === category ? T.accent : T.border}`,
                  borderRadius: 10,
                  padding: 0,
                  overflow: 'hidden',
                  position: 'relative',
                  cursor: 'pointer',
                  background: T.navy,
                }}
              >
                <img src={image} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: 0.7 }} />
                <span
                  style={{
                    position: 'absolute',
                    inset: 0,
                    display: 'flex',
                    alignItems: 'flex-end',
                    padding: '14px',
                    background: 'linear-gradient(180deg, transparent 30%, rgba(18,30,54,0.94) 100%)',
                    color: T.onNavy,
                    fontFamily: T.sans,
                    fontSize: 12,
                    fontWeight: 600,
                  }}
                >
                  {category}
                </span>
              </button>
            ))}
          </div>

          <div
            ref={productsSectionRef}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-end',
              marginBottom: 14,
              scrollMarginTop: 18,
            }}
          >
            <div>
              <h2 style={{ ...s.h2, fontSize: 21, marginBottom: 4 }}>Produtos em destaque</h2>
              <p style={s.bodySmall}>
                {normalizedQuery
                  ? `Resultados para “${searchQuery.trim()}”`
                  : customerState === 'new'
                    ? 'Os favoritos dos nossos clientes.'
                    : 'Uma seleção pensada para o seu perfil.'}
              </p>
            </div>
            <span style={s.label}>{displayed.length} produtos</span>
          </div>

          <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                style={{
                  ...s.btnGhost,
                  padding: '7px 13px',
                  fontSize: 9,
                  background: activeCategory === cat ? T.navy : T.base,
                  color: activeCategory === cat ? T.onNavy : T.muted,
                  borderColor: activeCategory === cat ? T.navy : T.border,
                }}
              >
                {cat}
              </button>
            ))}
          </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
            gap: 14,
          }}
        >
          {displayed.map((p) => (
            <ProductCard key={p.id} product={p} onAdd={onAdd} />
          ))}
        </div>
        {displayed.length === 0 && (
          <div style={{ ...s.body, color: T.muted, padding: '48px 0' }}>
            Nenhum produto nesta categoria no momento.
          </div>
        )}
          <div
            style={{
              marginTop: 30,
              minHeight: 150,
              borderRadius: 12,
              padding: '30px 34px',
              background: `linear-gradient(100deg, ${T.navy} 0%, ${T.navyDark} 68%)`,
              color: T.onNavy,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              overflow: 'hidden',
            }}
          >
            <div>
              <div style={{ fontFamily: T.serif, fontSize: 25, marginBottom: 6 }}>Seu próximo upgrade está aqui.</div>
              <div style={{ ...s.bodySmall, color: T.onNavyMuted }}>Tecnologia que acompanha o seu ritmo.</div>
            </div>
            <button
              onClick={() => onNavigate('recommended')}
              style={{ ...s.btnPrimary, background: T.accent }}
            >
              Ver recomendações →
            </button>
          </div>

          <footer
            style={{
              marginTop: 30,
              paddingTop: 22,
              borderTop: `1px solid ${T.border}`,
              display: 'flex',
              justifyContent: 'space-between',
              color: T.muted,
            }}
          >
            <span style={{ ...s.label, color: T.navy }}>VANTIX · Eletrônicos &amp; Informática</span>
            <span style={s.label}>Compra segura · Entrega rápida · Suporte especializado</span>
          </footer>
        </div>
      </div>
    </div>
  )
}

// ─── Recommended screen ────────────────────────────────────────────────────────

function RecommendedScreen({
  onAdd,
  customerState,
}: {
  onAdd: (p: Product) => void
  customerState: CustomerState
}) {
  const recommended = PRODUCTS.filter((p) => p.recommendReason)

  if (customerState === 'new') {
    return (
      <div style={{ flex: 1, height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <ScreenHeader title="Recomendados para você" />
        <EmptyState
          title="Ainda sem recomendações"
          body="Suas recomendações aparecem aqui depois da primeira compra. Usamos apenas o histórico de pedidos — sem rastrear navegação."
        />
      </div>
    )
  }

  return (
    <div style={{ flex: 1, height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader
        title="Recomendados para você"
        subtitle={
          <>
            Baseado em <strong style={{ color: T.text, fontWeight: 500 }}>Notebooks, Periféricos e Áudio</strong> — suas categorias mais compradas.
          </>
        }
      />
      <div style={{ flex: 1, overflowY: 'auto', padding: '28px 36px 36px', background: T.canvas }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 20 }}>
          {recommended.map((p) => (
            <ProductCard key={p.id} product={p} onAdd={onAdd} showReason />
          ))}
        </div>
      </div>
    </div>
  )
}

// ─── Orders screen ─────────────────────────────────────────────────────────────

function OrdersScreen({ customerState }: { customerState: CustomerState }) {
  if (customerState === 'new') {
    return (
      <div style={{ flex: 1, height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <ScreenHeader title="Meus pedidos" />
        <EmptyState
          title="Nenhum pedido ainda"
          body="Seu histórico de compras aparecerá aqui após a primeira compra."
        />
      </div>
    )
  }

  return (
    <div style={{ flex: 1, height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader
        title="Meus pedidos"
        right={
          <span style={{ ...s.label }}>
            {ORDERS.length} pedidos
          </span>
        }
      />

      <div style={{ flex: 1, overflowY: 'auto', padding: '0 36px 32px', background: T.canvas }}>
        {/* Table header */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '168px 1fr 110px 90px 120px',
            gap: 0,
            padding: '14px 0',
            borderBottom: `1px solid ${T.border}`,
            position: 'sticky',
            top: 0,
            background: T.base,
            zIndex: 1,
          }}
        >
          {['Pedido', 'Itens', 'Total', 'Pontos', 'Status'].map((h) => (
            <span key={h} style={s.label}>
              {h}
            </span>
          ))}
        </div>

        {ORDERS.map((order, idx) => (
          <div
            key={order.id}
            style={{
              display: 'grid',
              gridTemplateColumns: '168px 1fr 110px 90px 120px',
              gap: 0,
              padding: '16px 0',
              alignItems: 'start',
              borderBottom: `1px solid ${T.borderLight}`,
              background: idx % 2 === 0 ? 'transparent' : 'rgba(232,238,247,0.3)',
              transition: 'background 0.1s',
            }}
          >
            {/* ID + date */}
            <div>
              <div
                style={{
                  fontFamily: T.mono,
                  fontSize: 11,
                  fontWeight: 500,
                  color: T.navy,
                  marginBottom: 3,
                  letterSpacing: '0.02em',
                }}
              >
                {order.id}
              </div>
              <div style={{ ...s.label, textTransform: 'none', letterSpacing: 0, color: T.muted, fontWeight: 400, fontSize: 11 }}>
                {order.date}
              </div>
            </div>

            {/* Items */}
            <div>
              {order.items.map((item, i) => (
                <div key={i} style={{ ...s.body, fontSize: 12, marginBottom: 3, color: T.text }}>
                  {item.qty > 1 && (
                    <span style={{ fontFamily: T.mono, fontSize: 11, marginRight: 4, color: T.muted }}>
                      {item.qty}×
                    </span>
                  )}
                  {item.name}
                </div>
              ))}
            </div>

            {/* Total */}
            <div style={{ ...s.price, fontSize: 13 }}>{fmtBRL(order.total)}</div>

            {/* Points */}
            <div
              style={{
                fontFamily: T.mono,
                fontSize: 13,
                fontWeight: 600,
                color: T.accent,
                fontVariantNumeric: 'tabular-nums',
                letterSpacing: '-0.01em',
              }}
            >
              +{order.points.toLocaleString('pt-BR')}
            </div>

            {/* Status badge */}
            <div>
              <StatusBadge status={order.status} />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── Account screen ────────────────────────────────────────────────────────────

function AccountScreen({
  loyalty,
  points,
  levelingUp,
  customerState,
}: {
  loyalty: Loyalty
  points: number
  levelingUp: boolean
  customerState: CustomerState
}) {
  const ldata = loyaltyData[loyalty]
  const nextLoyalty: Loyalty | null =
    loyalty === 'bronze' ? 'prata' : loyalty === 'prata' ? 'ouro' : null
  const nextMin = nextLoyalty ? loyaltyData[nextLoyalty].min : null
  const progress = nextMin ? Math.min(points / nextMin, 1) : 1

  const effectiveLoyalty = levelingUp && nextLoyalty ? nextLoyalty : loyalty
  const effectiveData = loyaltyData[effectiveLoyalty]

  if (customerState === 'new') {
    return (
      <div style={{ flex: 1, height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <ScreenHeader title="Painel do cliente" />
        <EmptyState
          title="Você ainda não tem uma conta"
          body="Crie uma conta para acumular pontos a cada compra, subir de nível e receber recomendações baseadas no seu histórico."
        />
      </div>
    )
  }

  const statCardStyle: React.CSSProperties = {
    border: `1px solid ${T.border}`,
    borderRadius: 10,
    background: T.base,
    overflow: 'hidden',
  }

  return (
    <div style={{ flex: 1, height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <ScreenHeader title="Painel do cliente" />

      <div style={{ flex: 1, overflowY: 'auto', padding: '28px 36px 36px', background: T.canvas }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, maxWidth: 700 }}>

          {/* Loyalty block */}
          <div style={statCardStyle}>
            <div
              style={{
                height: 3,
                background: effectiveData.color,
                transition: 'background 1.2s ease',
              }}
            />
            <div style={{ padding: '20px 22px 22px' }}>
              <div style={s.label}>Nível de fidelidade</div>
              <div
                style={{
                  fontFamily: T.serif,
                  fontWeight: 500,
                  fontSize: 26,
                  color: effectiveData.color,
                  marginTop: 6,
                  marginBottom: 18,
                  transition: 'color 1.2s ease',
                  letterSpacing: '-0.01em',
                }}
              >
                {effectiveData.label}
              </div>

              {nextMin && (
                <>
                  <div
                    style={{
                      height: 3,
                      background: T.borderLight,
                      borderRadius: 2,
                      marginBottom: 7,
                      overflow: 'hidden',
                    }}
                  >
                    <div
                      style={{
                        height: '100%',
                        width: `${progress * 100}%`,
                        background: ldata.color,
                        borderRadius: 2,
                        transition: 'width 0.8s ease',
                      }}
                    />
                  </div>
                  <div style={s.label}>
                    {(nextMin - points).toLocaleString('pt-BR')} pontos para {nextLoyalty && loyaltyData[nextLoyalty].label}
                  </div>
                </>
              )}
              {!nextMin && <div style={s.label}>Nível máximo atingido</div>}
            </div>
          </div>

          {/* Points block */}
          <div style={{ ...statCardStyle, padding: '20px 22px 22px' }}>
            <div style={s.label}>Pontos acumulados</div>
            <div
              style={{
                fontFamily: T.mono,
                fontWeight: 600,
                fontSize: 40,
                color: T.accent,
                marginTop: 8,
                fontVariantNumeric: 'tabular-nums',
                letterSpacing: '-0.04em',
                lineHeight: 1,
              }}
            >
              {points.toLocaleString('pt-BR')}
            </div>
            <div
              style={{
                marginTop: 10,
                fontFamily: T.sans,
                fontSize: 12,
                color: T.muted,
                lineHeight: 1.4,
              }}
            >
              Equivalem a{' '}
              <span style={{ color: T.text, fontWeight: 500 }}>{fmtBRL(points * 0.01)}</span>{' '}
              em desconto
            </div>
          </div>

          {/* Summary stats */}
          <div style={{ gridColumn: '1 / -1', ...statCardStyle }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)' }}>
              {[
                {
                  label: 'Pedidos realizados',
                  value: ORDERS.length.toString(),
                  mono: false,
                },
                {
                  label: 'Total investido',
                  value: fmtBRL(ORDERS.reduce((s, o) => s + o.total, 0)),
                  mono: true,
                },
                { label: 'Categorias compradas', value: '3', mono: false },
              ].map((stat, i) => (
                <div
                  key={stat.label}
                  style={{
                    padding: '20px 24px',
                    borderRight: i < 2 ? `1px solid ${T.border}` : 'none',
                  }}
                >
                  <div style={s.label}>{stat.label}</div>
                  <div
                    style={{
                      ...(stat.mono ? s.priceLg : {}),
                      fontFamily: stat.mono ? T.mono : T.serif,
                      fontWeight: 600,
                      fontSize: stat.mono ? 20 : 28,
                      color: T.navy,
                      marginTop: 6,
                      letterSpacing: stat.mono ? '-0.03em' : '-0.02em',
                    }}
                  >
                    {stat.value}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent activity label */}
          <div style={{ gridColumn: '1 / -1' }}>
            <div style={{ ...s.label, marginBottom: 14 }}>Últimos pedidos</div>
            {ORDERS.slice(0, 2).map((order) => (
              <div
                key={order.id}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '12px 16px',
                  border: `1px solid ${T.borderLight}`,
                  borderRadius: 3,
                  marginBottom: 8,
                  background: T.base,
                }}
              >
                <div>
                  <div
                    style={{
                      fontFamily: T.mono,
                      fontSize: 11,
                      color: T.navy,
                      fontWeight: 500,
                      marginBottom: 2,
                    }}
                  >
                    {order.id}
                  </div>
                  <div style={{ ...s.bodySmall, fontSize: 11 }}>{order.date}</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <span style={{ ...s.price, fontSize: 13 }}>{fmtBRL(order.total)}</span>
                  <StatusBadge status={order.status} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Cart ──────────────────────────────────────────────────────────────────────

function Cart({
  items,
  onQty,
  onRemove,
  onCheckout,
}: {
  items: CartItem[]
  onQty: (id: number, delta: number) => void
  onRemove: (id: number) => void
  onCheckout: (points: number) => void
}) {
  const [payment, setPayment] = useState<Payment>('pix')
  const [installments, setInstallments] = useState(1)
  const [confirmed, setConfirmed] = useState(false)

  const subtotal = items.reduce((s, i) => s + i.product.price * i.qty, 0)
  const fee = subtotal * paymentFee[payment]
  const total = subtotal + fee
  const earnedPoints = Math.floor(total / 10)

  const handleConfirm = () => {
    setConfirmed(true)
    onCheckout(earnedPoints)
  }

  if (confirmed) {
    return (
      <aside
        style={{
          width: 288,
          minWidth: 288,
          height: '100%',
          background: T.surface,
          borderLeft: `1px solid ${T.border}`,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: 36,
          flexShrink: 0,
          textAlign: 'center',
        }}
      >
        <div
          style={{
            width: 32,
            height: 32,
            borderRadius: '50%',
            border: `2px solid ${T.navy}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 20,
            color: T.navy,
            fontSize: 14,
          }}
        >
          ✓
        </div>
        <h2 style={{ ...s.h2, marginBottom: 8 }}>Pedido confirmado</h2>
        <p style={{ ...s.bodySmall, marginBottom: 20, lineHeight: 1.65 }}>
          Você ganhou{' '}
          <span style={{ fontFamily: T.mono, color: T.accent, fontWeight: 600 }}>
            +{earnedPoints.toLocaleString('pt-BR')}
          </span>{' '}
          pontos nesta compra.
        </p>
        <button
          onClick={() => setConfirmed(false)}
          style={{ ...s.btnGhost, fontSize: 10 }}
        >
          Novo pedido
        </button>
      </aside>
    )
  }

  return (
    <aside
      style={{
        width: 288,
        minWidth: 288,
        height: '100%',
        background: T.base,
        borderLeft: `1px solid ${T.border}`,
        display: 'flex',
        flexDirection: 'column',
        flexShrink: 0,
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: '24px 20px 16px',
          borderBottom: `1px solid ${T.border}`,
          background: T.surface,
          flexShrink: 0,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <span style={{ fontFamily: T.serif, fontWeight: 500, fontSize: 17, color: T.navy, letterSpacing: '-0.01em' }}>
          Carrinho
        </span>
        {items.length > 0 && (
          <span
            style={{
              ...s.label,
              background: T.navy,
              color: T.onNavy,
              padding: '2px 7px',
              borderRadius: 10,
              fontSize: 9,
            }}
          >
            {items.reduce((s, i) => s + i.qty, 0)}
          </span>
        )}
      </div>

      {/* Items */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
        {items.length === 0 ? (
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              height: '100%',
              paddingBottom: 48,
            }}
          >
            <div style={{ width: 20, height: 1, background: T.border, marginBottom: 14 }} />
            <p style={s.bodySmall}>Nenhum item adicionado.</p>
          </div>
        ) : (
          items.map((item) => (
            <div
              key={item.product.id}
              style={{
                borderBottom: `1px solid ${T.borderLight}`,
                padding: '14px 0',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: 10,
                  marginBottom: 10,
                }}
              >
                <img
                  src={item.product.image}
                  alt=""
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 4,
                    objectFit: 'cover',
                    border: `1px solid ${T.borderLight}`,
                    flexShrink: 0,
                  }}
                />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ ...s.label, marginBottom: 2 }}>{item.product.brand}</div>
                  <div
                    style={{
                      fontFamily: T.sans,
                      fontSize: 13,
                      fontWeight: 500,
                      color: T.text,
                      lineHeight: 1.3,
                    }}
                  >
                    {item.product.name}
                  </div>
                </div>
                <button
                  onClick={() => onRemove(item.product.id)}
                  style={{
                    background: 'none',
                    border: `1px solid ${T.borderLight}`,
                    borderRadius: 2,
                    color: T.muted,
                    cursor: 'pointer',
                    fontSize: 10,
                    padding: '2px 5px',
                    lineHeight: 1.4,
                    flexShrink: 0,
                    transition: 'border-color 0.12s',
                  }}
                >
                  ✕
                </button>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <button
                    onClick={() => onQty(item.product.id, -1)}
                    style={{
                      width: 26, height: 26,
                      border: `1px solid ${T.border}`,
                      borderRadius: '2px 0 0 2px',
                      background: T.surface,
                      color: T.muted,
                      cursor: 'pointer',
                      fontSize: 14,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      transition: 'background 0.1s',
                    }}
                  >
                    −
                  </button>
                  <span
                    style={{
                      width: 30, height: 26,
                      border: `1px solid ${T.border}`,
                      borderLeft: 'none', borderRight: 'none',
                      background: T.base,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontFamily: T.mono, fontSize: 12, fontWeight: 600, color: T.text,
                    }}
                  >
                    {item.qty}
                  </span>
                  <button
                    onClick={() => onQty(item.product.id, 1)}
                    style={{
                      width: 26, height: 26,
                      border: `1px solid ${T.border}`,
                      borderRadius: '0 2px 2px 0',
                      background: T.surface,
                      color: T.muted,
                      cursor: 'pointer',
                      fontSize: 14,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      transition: 'background 0.1s',
                    }}
                  >
                    +
                  </button>
                </div>
                <span style={{ ...s.price, fontSize: 13 }}>
                  {fmtBRL(item.product.price * item.qty)}
                </span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer */}
      {items.length > 0 && (
        <div style={{ padding: '16px 20px 22px', borderTop: `1px solid ${T.border}`, flexShrink: 0 }}>
          {/* Payment */}
          <div style={{ marginBottom: 14 }}>
            <div style={{ ...s.label, marginBottom: 8 }}>Pagamento</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
              {([
                { id: 'pix', label: 'Pix', note: 'sem taxa' },
                { id: 'card', label: 'Cartão de crédito', note: '+3%' },
                { id: 'boleto', label: 'Boleto', note: '+1%' },
              ] as { id: Payment; label: string; note: string }[]).map((p, i, arr) => (
                <label
                  key={p.id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '8px 10px',
                    border: `1px solid ${payment === p.id ? T.navy : T.border}`,
                    borderTop: i === 0 ? `1px solid ${payment === p.id ? T.navy : T.border}` : 'none',
                    borderRadius: i === 0 ? '2px 2px 0 0' : i === arr.length - 1 ? '0 0 2px 2px' : 0,
                    background: payment === p.id ? T.surface : T.base,
                    cursor: 'pointer',
                    transition: 'border-color 0.12s, background 0.12s',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <input
                      type="radio"
                      name="payment"
                      value={p.id}
                      checked={payment === p.id}
                      onChange={() => setPayment(p.id)}
                      style={{ accentColor: T.navy, cursor: 'pointer' }}
                    />
                    <span style={{ fontFamily: T.sans, fontSize: 12, color: T.text }}>{p.label}</span>
                  </div>
                  <span style={{ ...s.label, textTransform: 'none', letterSpacing: 0, fontWeight: 400, fontSize: 11 }}>
                    {p.note}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Installments */}
          {payment === 'card' && (
            <div style={{ marginBottom: 14 }}>
              <div style={{ ...s.label, marginBottom: 6 }}>Parcelas</div>
              <select
                value={installments}
                onChange={(e) => setInstallments(Number(e.target.value))}
                style={{
                  width: '100%',
                  padding: '7px 10px',
                  border: `1px solid ${T.border}`,
                  borderRadius: 2,
                  background: T.base,
                  color: T.text,
                  fontFamily: T.sans,
                  fontSize: 12,
                  cursor: 'pointer',
                  outline: 'none',
                }}
              >
                {[1, 2, 3, 6, 10, 12].map((n) => (
                  <option key={n} value={n}>
                    {n}× de {fmtBRL(total / n)} sem juros
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Totals */}
          <div
            style={{
              padding: '12px 14px',
              background: T.surface,
              borderRadius: 3,
              marginBottom: 12,
            }}
          >
            {fee > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={s.label}>Taxa</span>
                <span
                  style={{
                    fontFamily: T.mono,
                    fontSize: 12,
                    color: T.muted,
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  +{fmtBRL(fee)}
                </span>
              </div>
            )}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span style={{ fontFamily: T.sans, fontSize: 12, fontWeight: 500, color: T.muted, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                Total
              </span>
              <span style={s.priceLg}>{fmtBRL(total)}</span>
            </div>
            <div
              style={{
                fontFamily: T.sans,
                fontSize: 10,
                color: T.accent,
                fontWeight: 500,
                letterSpacing: '0.04em',
                textTransform: 'uppercase',
                marginTop: 6,
                textAlign: 'right',
              }}
            >
              +{earnedPoints.toLocaleString('pt-BR')} pontos ao confirmar
            </div>
          </div>

          <button
            onClick={handleConfirm}
            style={{ ...s.btnPrimary, width: '100%', justifyContent: 'center', padding: '11px 0' }}
          >
            Confirmar pedido
          </button>
        </div>
      )}
    </aside>
  )
}

// ─── New Customer Modal ────────────────────────────────────────────────────────

function NewCustomerModal({ onClose, onSubmit }: { onClose: () => void; onSubmit: () => void }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [done, setDone] = useState(false)

  const inputStyle: React.CSSProperties = {
    width: '100%',
    padding: '10px 12px',
    border: `1px solid ${T.border}`,
    borderRadius: 2,
    background: T.base,
    color: T.text,
    fontFamily: T.sans,
    fontSize: 13,
    outline: 'none',
    transition: 'border-color 0.12s',
  }

  const handleSubmit = () => {
    if (name && email) {
      setDone(true)
      setTimeout(() => {
        onSubmit()
        onClose()
      }, 1800)
    }
  }

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(18, 30, 54, 0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 200,
        backdropFilter: 'blur(2px)',
      }}
      onClick={onClose}
    >
      <div
        style={{
          background: T.base,
          border: `1px solid ${T.border}`,
          borderRadius: 4,
          width: 400,
          overflow: 'hidden',
          boxShadow: '0 24px 48px rgba(18,30,54,0.16)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Navy accent line */}
        <div style={{ height: 3, background: T.navy }} />

        <div style={{ padding: '28px 28px 26px' }}>
          {done ? (
            <div>
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: '50%',
                  border: `2px solid ${T.navy}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: T.navy,
                  fontSize: 14,
                  marginBottom: 18,
                }}
              >
                ✓
              </div>
              <h2 style={{ ...s.h2, marginBottom: 8 }}>Conta criada</h2>
              <p style={{ ...s.bodySmall, lineHeight: 1.65 }}>
                Bem-vindo, {name}. Sua conta está no nível{' '}
                <span style={{ color: T.bronze, fontWeight: 500 }}>Bronze</span> com 0 pontos.
                As recomendações personalizadas aparecerão após a primeira compra.
              </p>
            </div>
          ) : (
            <>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  marginBottom: 26,
                }}
              >
                <div>
                  <h2 style={{ ...s.h2, marginBottom: 4 }}>Nova conta</h2>
                  <p style={s.bodySmall}>Acumule pontos a cada compra realizada.</p>
                </div>
                <button
                  onClick={onClose}
                  style={{
                    background: 'none',
                    border: `1px solid ${T.border}`,
                    borderRadius: 2,
                    color: T.muted,
                    cursor: 'pointer',
                    padding: '3px 8px',
                    fontSize: 12,
                    fontFamily: T.sans,
                    transition: 'border-color 0.12s',
                  }}
                >
                  ✕
                </button>
              </div>

              <div style={{ marginBottom: 14 }}>
                <div style={{ ...s.label, marginBottom: 6 }}>Nome completo</div>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ana Beatriz Souza"
                  style={inputStyle}
                />
              </div>

              <div style={{ marginBottom: 20 }}>
                <div style={{ ...s.label, marginBottom: 6 }}>E-mail</div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ana@exemplo.com"
                  style={inputStyle}
                />
              </div>

              <div
                style={{
                  padding: '11px 14px',
                  background: T.surface,
                  border: `1px solid ${T.border}`,
                  borderRadius: 3,
                  marginBottom: 22,
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                <span style={s.bodySmall}>Nível inicial</span>
                <span
                  style={{
                    fontFamily: T.sans,
                    fontSize: 12,
                    fontWeight: 500,
                    color: T.bronze,
                    letterSpacing: '0.03em',
                  }}
                >
                  Bronze · 0 pts
                </span>
              </div>

              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={onClose} style={{ ...s.btnGhost, flex: 1, justifyContent: 'center' }}>
                  Cancelar
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={!name || !email}
                  style={{
                    ...s.btnPrimary,
                    flex: 2,
                    justifyContent: 'center',
                    background: name && email ? T.navy : T.border,
                    color: name && email ? T.onNavy : T.muted,
                    cursor: name && email ? 'pointer' : 'default',
                  }}
                >
                  Criar conta
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Mobile layout ─────────────────────────────────────────────────────────────

function MobileView({ customerState }: { customerState: CustomerState }) {
  const [tab, setTab] = useState<'catalog' | 'rec' | 'orders'>('catalog')
  const [cartOpen, setCartOpen] = useState(false)
  const [cart, setCart] = useState<CartItem[]>([])
  const [category, setCategory] = useState('Todos')

  const addToCart = (p: Product) => {
    setCart((prev) => {
      const ex = prev.find((i) => i.product.id === p.id)
      return ex
        ? prev.map((i) => (i.product.id === p.id ? { ...i, qty: i.qty + 1 } : i))
        : [...prev, { product: p, qty: 1 }]
    })
  }

  const totalItems = cart.reduce((s, i) => s + i.qty, 0)
  const subtotal = cart.reduce((s, i) => s + i.product.price * i.qty, 0)

  const displayed =
    tab === 'catalog'
      ? customerState === 'new'
        ? PRODUCTS.filter((p) => p.popular && (category === 'Todos' || p.category === category))
        : PRODUCTS.filter((p) => category === 'Todos' || p.category === category)
      : tab === 'rec'
      ? PRODUCTS.filter((p) => p.recommendReason)
      : []

  return (
    <div
      style={{
        width: 375,
        height: 812,
        border: `1px solid ${T.border}`,
        borderRadius: 14,
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        background: T.canvas,
        position: 'relative',
        flexShrink: 0,
        boxShadow: '0 20px 60px rgba(18,30,54,0.12)',
      }}
    >
      {/* Header */}
      <div
        style={{
          background: `linear-gradient(180deg, ${T.navy} 0%, ${T.navyDark} 100%)`,
          padding: '12px 20px 10px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexShrink: 0,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontFamily: T.serif, fontWeight: 500, fontSize: 16, color: T.onNavy }}>Vantix</span>
          <span style={{ width: 4, height: 4, borderRadius: '50%', background: T.accent, display: 'inline-block' }} />
        </div>
        <button
          onClick={() => setCartOpen(!cartOpen)}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            fontFamily: T.sans,
            fontSize: 11,
            color: T.onNavy,
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            padding: '4px 0',
            letterSpacing: '0.04em',
            textTransform: 'uppercase',
            fontWeight: 500,
          }}
        >
          Carrinho
          {totalItems > 0 && (
            <span
              style={{
                background: T.accent,
                color: '#fff',
                borderRadius: 10,
                padding: '1px 6px',
                fontFamily: T.mono,
                fontSize: 10,
                fontWeight: 600,
              }}
            >
              {totalItems}
            </span>
          )}
        </button>
      </div>

      {/* Category strip */}
      {tab === 'catalog' && (
        <div
          style={{
            display: 'flex',
            overflowX: 'auto',
            gap: 0,
            padding: '0 16px',
            borderBottom: `1px solid ${T.border}`,
            flexShrink: 0,
          }}
        >
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              style={{
                padding: '11px 12px',
                background: 'transparent',
                color: category === c ? T.navy : T.muted,
                fontFamily: T.sans,
                fontSize: 12,
                fontWeight: category === c ? 500 : 400,
                border: 'none',
                borderBottom: category === c ? `2px solid ${T.navy}` : '2px solid transparent',
                marginBottom: -1,
                cursor: 'pointer',
                whiteSpace: 'nowrap',
                outline: 'none',
              }}
            >
              {c}
            </button>
          ))}
        </div>
      )}

      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '0 16px' }}>
        {tab === 'orders' ? (
          <div>
            <div style={{ padding: '16px 0 4px' }}>
              <h2 style={{ ...s.h2, fontSize: 16 }}>Meus pedidos</h2>
            </div>
            {customerState === 'new' ? (
              <p style={{ ...s.bodySmall, marginTop: 12, lineHeight: 1.6 }}>
                Nenhum pedido ainda. Explore o catálogo para começar.
              </p>
            ) : (
              ORDERS.map((order) => (
                <div key={order.id} style={{ borderBottom: `1px solid ${T.borderLight}`, padding: '12px 0' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                    <span style={{ fontFamily: T.mono, fontSize: 11, color: T.navy, fontWeight: 500 }}>{order.id}</span>
                    <span style={{ ...s.price, fontSize: 13 }}>{fmtBRL(order.total)}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                    <span style={{ ...s.bodySmall, fontSize: 11 }}>{order.date}</span>
                    <StatusBadge status={order.status} />
                  </div>
                  {order.items.map((item, i) => (
                    <div key={i} style={{ ...s.bodySmall, fontSize: 11 }}>{item.qty}× {item.name}</div>
                  ))}
                </div>
              ))
            )}
          </div>
        ) : tab === 'rec' && customerState === 'new' ? (
          <div style={{ padding: '32px 0' }}>
            <div style={{ width: 24, height: 2, background: T.accent, borderRadius: 1, marginBottom: 14 }} />
            <p style={{ ...s.bodySmall, lineHeight: 1.65 }}>
              Recomendações aparecem após a primeira compra.
            </p>
          </div>
        ) : (
          displayed.map((p) => (
            <div
              key={p.id}
              style={{
                border: `1px solid ${T.borderLight}`,
                borderRadius: 10,
                overflow: 'hidden',
                margin: '14px 0',
                background: T.base,
                boxShadow: '0 4px 16px rgba(18,30,54,0.05)',
              }}
            >
              <div style={{ display: 'flex' }}>
                <img
                  src={p.image}
                  alt={p.imageAlt}
                  loading="lazy"
                  style={{
                    width: 112,
                    minHeight: 126,
                    objectFit: 'cover',
                    borderRight: `1px solid ${T.borderLight}`,
                    flexShrink: 0,
                  }}
                />
                <div style={{ padding: '12px 13px', flex: 1, minWidth: 0 }}>
                  <div style={s.label}>{p.brand}</div>
                  <div
                    style={{
                      fontFamily: T.serif,
                      fontSize: 15,
                      fontWeight: 500,
                      color: T.navy,
                      marginBottom: 4,
                      marginTop: 3,
                      letterSpacing: '-0.01em',
                      lineHeight: 1.25,
                    }}
                  >
                    {p.name}
                  </div>
                  {tab === 'rec' && p.recommendReason && (
                    <div
                      style={{
                        fontFamily: T.sans,
                        fontSize: 10,
                        color: T.accent,
                        marginBottom: 6,
                        lineHeight: 1.4,
                      }}
                    >
                      {p.recommendReason}
                    </div>
                  )}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}>
                    <span style={{ ...s.price, fontSize: 13 }}>{fmtBRL(p.price)}</span>
                    <button
                      onClick={() => addToCart(p)}
                      style={{ ...s.btnPrimary, fontSize: 9, padding: '6px 10px' }}
                    >
                      Adicionar
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Bottom nav */}
      <div
        style={{
          borderTop: `1px solid ${T.border}`,
          display: 'grid',
          gridTemplateColumns: '1fr 1fr 1fr',
          flexShrink: 0,
          background: T.base,
        }}
      >
        {([
          { id: 'catalog', label: 'Catálogo' },
          { id: 'rec', label: 'Para você' },
          { id: 'orders', label: 'Pedidos' },
        ] as { id: 'catalog' | 'rec' | 'orders'; label: string }[]).map((item) => (
          <button
            key={item.id}
            onClick={() => setTab(item.id)}
            style={{
              padding: '13px 0',
              background: 'transparent',
              borderTop: tab === item.id ? `2px solid ${T.navy}` : '2px solid transparent',
              border: 'none',
              color: tab === item.id ? T.navy : T.muted,
              fontFamily: T.sans,
              fontSize: 11,
              fontWeight: tab === item.id ? 500 : 400,
              cursor: 'pointer',
              outline: 'none',
              letterSpacing: '0.02em',
            }}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Cart overlay */}
      {cartOpen && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: T.base,
            display: 'flex',
            flexDirection: 'column',
            zIndex: 10,
          }}
        >
          <div
            style={{
              padding: '16px 20px',
              borderBottom: `1px solid ${T.border}`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              background: T.surface,
            }}
          >
            <span style={{ fontFamily: T.serif, fontWeight: 500, fontSize: 16, color: T.navy, letterSpacing: '-0.01em' }}>
              Carrinho
            </span>
            <button
              onClick={() => setCartOpen(false)}
              style={{
                background: 'none',
                border: `1px solid ${T.border}`,
                borderRadius: 2,
                color: T.muted,
                cursor: 'pointer',
                fontSize: 11,
                padding: '3px 10px',
                fontFamily: T.sans,
              }}
            >
              Fechar
            </button>
          </div>
          <div style={{ flex: 1, overflowY: 'auto', padding: '0 20px' }}>
            {cart.length === 0 ? (
              <p style={{ ...s.bodySmall, padding: '24px 0' }}>Nenhum item adicionado.</p>
            ) : (
              cart.map((item) => (
                <div key={item.product.id} style={{ borderBottom: `1px solid ${T.borderLight}`, padding: '14px 0' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <div style={s.label}>{item.product.brand}</div>
                      <div style={{ fontFamily: T.sans, fontSize: 12, fontWeight: 500, color: T.text, marginTop: 2 }}>
                        {item.product.name}
                      </div>
                    </div>
                    <span style={{ ...s.price, fontSize: 13 }}>{fmtBRL(item.product.price * item.qty)}</span>
                  </div>
                </div>
              ))
            )}
          </div>
          {cart.length > 0 && (
            <div
              style={{
                padding: '16px 20px',
                borderTop: `1px solid ${T.border}`,
                background: T.surface,
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14, alignItems: 'baseline' }}>
                <span style={{ fontFamily: T.sans, fontSize: 12, fontWeight: 500, color: T.muted, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  Total
                </span>
                <span style={s.priceLg}>{fmtBRL(subtotal)}</span>
              </div>
              <button
                onClick={() => setCartOpen(false)}
                style={{ ...s.btnPrimary, width: '100%', justifyContent: 'center', padding: '12px 0' }}
              >
                Confirmar pedido
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>('catalog')
  const [cart, setCart] = useState<CartItem[]>([])
  const [showModal, setShowModal] = useState(false)
  const [customerState, setCustomerState] = useState<CustomerState>('returning')
  const [searchQuery, setSearchQuery] = useState('')
  const [loyalty, setLoyalty] = useState<Loyalty>('prata')
  const [points, setPoints] = useState(1892)
  const [levelingUp, setLevelingUp] = useState(false)
  const [viewMode, setViewMode] = useState<ViewMode>('desktop')

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const ex = prev.find((i) => i.product.id === product.id)
      return ex
        ? prev.map((i) => (i.product.id === product.id ? { ...i, qty: i.qty + 1 } : i))
        : [...prev, { product, qty: 1 }]
    })
  }

  const adjustQty = (id: number, delta: number) => {
    setCart((prev) =>
      prev.map((i) => (i.product.id === id ? { ...i, qty: i.qty + delta } : i)).filter((i) => i.qty > 0)
    )
  }

  const removeFromCart = (id: number) => {
    setCart((prev) => prev.filter((i) => i.product.id !== id))
  }

  const handleCheckout = (earned: number) => {
    if (customerState === 'new') return
    const newPoints = points + earned
    setPoints(newPoints)
    setCart([])

    const nextThreshold: Record<Loyalty, number | null> = { bronze: 1000, prata: 3000, ouro: null }
    const threshold = nextThreshold[loyalty]
    if (threshold && newPoints >= threshold) {
      setLevelingUp(true)
      setTimeout(() => {
        setLoyalty(loyalty === 'bronze' ? 'prata' : 'ouro')
        setLevelingUp(false)
      }, 2400)
    }
  }

  const handleNewCustomer = () => {
    setCustomerState('new')
    setPoints(0)
    setLoyalty('bronze')
    setShowModal(true)
  }

  const handleModalSubmit = () => {
    setCustomerState('returning')
  }

  if (viewMode === 'mobile') {
    return (
      <div
        style={{
          minHeight: '100vh',
          background: T.surface,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          padding: '28px 0 40px',
          overflowY: 'auto',
          gap: 28,
        }}
      >
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <button
            onClick={() => setViewMode('desktop')}
            style={{ ...s.btnGhost, fontSize: 10 }}
          >
            ← Desktop
          </button>
          <span style={s.label}>Variações mobile</span>
        </div>

        <div style={{ display: 'flex', gap: 36, alignItems: 'flex-start' }}>
          <div>
            <div style={{ ...s.label, marginBottom: 12, textAlign: 'center' }}>Cliente novo</div>
            <MobileView customerState="new" />
          </div>
          <div>
            <div style={{ ...s.label, marginBottom: 12, textAlign: 'center' }}>Cliente recorrente</div>
            <MobileView customerState="returning" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        width: '100vw',
        background: T.canvas,
        overflow: 'hidden',
        position: 'relative',
      }}
    >
      <StoreHeader
        screen={screen}
        onNav={setScreen}
        onNewCustomer={handleNewCustomer}
        searchQuery={searchQuery}
        onSearch={setSearchQuery}
        points={points}
        loyalty={loyalty}
        customerState={customerState}
      />

      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0, minHeight: 0 }}>
        {/* Prototype controls bar */}
        <div
          style={{
            borderBottom: `1px solid ${T.border}`,
            padding: '8px 36px',
            display: 'flex',
            justifyContent: 'flex-end',
            alignItems: 'center',
            gap: 6,
            flexShrink: 0,
            background: T.surface,
          }}
        >
          <span style={{ ...s.label, marginRight: 4 }}>Protótipo</span>
          {([
            { id: 'new', label: 'Cliente novo' },
            { id: 'returning', label: 'Cliente recorrente' },
            { id: 'leveling', label: 'Subindo de nível' },
          ] as { id: CustomerState; label: string }[]).map((opt) => (
            <button
              key={opt.id}
              onClick={() => {
                if (opt.id === 'leveling') {
                  setCustomerState('returning')
                  setPoints(2850)
                  setLoyalty('prata')
                  setLevelingUp(false)
                } else if (opt.id === 'new') {
                  setCustomerState('new')
                  setPoints(0)
                  setLoyalty('bronze')
                  setLevelingUp(false)
                } else {
                  setCustomerState('returning')
                  setPoints(1892)
                  setLoyalty('prata')
                  setLevelingUp(false)
                }
              }}
              style={{
                ...s.btnGhost,
                fontSize: 10,
                padding: '5px 11px',
                background:
                  customerState === opt.id && opt.id !== 'leveling' ? T.navy : 'transparent',
                color:
                  customerState === opt.id && opt.id !== 'leveling' ? T.onNavy : T.muted,
                borderColor:
                  customerState === opt.id && opt.id !== 'leveling' ? T.navy : T.border,
              }}
            >
              {opt.label}
            </button>
          ))}
          <div style={{ width: 1, height: 14, background: T.border, margin: '0 4px' }} />
          <button
            onClick={() => setViewMode('mobile')}
            style={{ ...s.btnGhost, fontSize: 10, padding: '5px 11px' }}
          >
            Ver mobile
          </button>
        </div>

        {/* Screen content */}
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          {screen === 'catalog' && (
            <CatalogScreen
              onAdd={addToCart}
              onNavigate={setScreen}
              searchQuery={searchQuery}
              customerState={customerState}
            />
          )}
          {screen === 'recommended' && (
            <RecommendedScreen onAdd={addToCart} customerState={customerState} />
          )}
          {screen === 'orders' && <OrdersScreen customerState={customerState} />}
          {screen === 'account' && (
            <AccountScreen
              loyalty={loyalty}
              points={points}
              levelingUp={levelingUp}
              customerState={customerState}
            />
          )}

          <Cart
            items={cart}
            onQty={adjustQty}
            onRemove={removeFromCart}
            onCheckout={handleCheckout}
          />
        </div>
      </main>

      {showModal && (
        <NewCustomerModal onClose={() => setShowModal(false)} onSubmit={handleModalSubmit} />
      )}

      {/* Level up trigger */}
      {customerState === 'returning' && points >= 2850 && !levelingUp && loyalty === 'prata' && (
        <button
          onClick={() => {
            setLevelingUp(true)
            const earned = 200
            const newPoints = points + earned
            setPoints(newPoints)
            setTimeout(() => {
              setLoyalty('ouro')
              setLevelingUp(false)
            }, 2400)
          }}
          style={{
            position: 'fixed',
            bottom: 22,
            right: 22,
            ...s.btnPrimary,
            fontSize: 10,
            padding: '9px 18px',
            background: T.gold,
            color: T.navyDark,
          }}
        >
          Simular compra → Ouro
        </button>
      )}
    </div>
  )
}
