# Firebase Setup — Maka Delivery

## 1. Criar usuários no Firebase Authentication

Acesse: https://console.firebase.google.com → maka-delivery-7382b → Authentication → Users → Add user

Crie os 3 usuários abaixo:

| E-mail                  | Senha    | Portal     |
|-------------------------|----------|------------|
| gerente@maka.com        | maka2024 | Gerente    |
| cozinha@maka.com        | maka2024 | Cozinha    |
| entregador@maka.com     | maka2024 | Entregador |

## 2. Configurar regras do Firestore

Acesse: Firestore Database → Regras → Cole o seguinte:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## 3. Rodar o projeto

```bash
npm install
npm start
```

O cardápio será populado automaticamente no Firestore na primeira execução.

## 4. URLs de acesso

| Portal     | URL                             | E-mail                  |
|------------|---------------------------------|-------------------------|
| Cliente    | http://localhost:4200           | (sem login)             |
| Gerente    | http://localhost:4200/login/manager  | gerente@maka.com   |
| Cozinha    | http://localhost:4200/login/kitchen  | cozinha@maka.com   |
| Entregador | http://localhost:4200/login/delivery | entregador@maka.com|
